package stairs;
public class MyStairs {
    public static void main(String[] args) {
        int num = 4;
        for (int i = 0; i<num; i++)
            System.out.println("");
    }
    
}
