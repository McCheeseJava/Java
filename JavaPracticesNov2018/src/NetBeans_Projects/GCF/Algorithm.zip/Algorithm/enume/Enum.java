package enume;
public class Enum {
public enum Season {spring, summer, fall, winter};
    public static void main(String[] args) {
        System.out.println(Season.fall);
    }    
}
